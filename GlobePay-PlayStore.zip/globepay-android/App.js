import React, { useEffect, useRef, useState } from 'react';
import { ActivityIndicator, BackHandler, Linking, StyleSheet, View } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import SITE from './src/site';

// The whole GlobePay app (dashboard, payments, card, profile, 3D Earth) is bundled
// inside the app and runs offline. A fixed https base URL gives it its own origin,
// so the app's saved data (localStorage) survives restarts.
const BASE_URL = 'https://app.globepay.local/';

SplashScreen.preventAutoHideAsync().catch(() => {});

export default function App() {
  const web = useRef(null);
  const [loaded, setLoaded] = useState(false);

  // Android back button: step back inside GlobePay; leave the app only from Overview.
  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      web.current?.injectJavaScript(
        "window.ReactNativeWebView.postMessage(JSON.stringify({back: !!(window.__gpBack && window.__gpBack())}));true;"
      );
      return true;
    });
    return () => sub.remove();
  }, []);

  const onMessage = (e) => {
    try {
      const msg = JSON.parse(e.nativeEvent.data);
      if (msg.back === false) BackHandler.exitApp();
    } catch (err) {}
  };

  // Open any outside link in the phone's browser instead of inside the app.
  const onNavigate = (req) => {
    const url = req.url || '';
    if (url.startsWith(BASE_URL) || url.startsWith('about:') || url.startsWith('data:') || url.startsWith('blob:')) return true;
    if (/^(https?|mailto|tel):/.test(url)) {
      Linking.openURL(url).catch(() => {});
      return false;
    }
    return true;
  };

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.root} edges={['top', 'bottom']}>
        <StatusBar style="light" />
        <WebView
          ref={web}
          source={{ html: SITE, baseUrl: BASE_URL }}
          originWhitelist={['*']}
          javaScriptEnabled
          domStorageEnabled
          textZoom={100}
          overScrollMode="never"
          setSupportMultipleWindows={false}
          allowFileAccess={false}
          mediaPlaybackRequiresUserAction
          onShouldStartLoadWithRequest={onNavigate}
          onMessage={onMessage}
          onLoadEnd={() => {
            setLoaded(true);
            SplashScreen.hideAsync().catch(() => {});
          }}
          style={styles.web}
        />
        {!loaded ? (
          <View style={styles.loading} pointerEvents="none">
            <ActivityIndicator size="large" color="#2997FF" />
          </View>
        ) : null}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#000' },
  web: { flex: 1, backgroundColor: '#000' },
  loading: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', backgroundColor: '#000' },
});

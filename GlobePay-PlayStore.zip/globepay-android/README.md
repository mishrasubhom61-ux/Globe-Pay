# GlobePay for Android (Play Store version)

This is the full GlobePay app — dashboard, Send, Pay, Get paid, Convert, Card, Activity, Business, Profile, the real 3D Earth and the Milky Way — packaged as a native Android app. Everything is bundled inside, so it works offline. It is a concept demo: no real money moves.

The store graphics, listing text and privacy policy are in the separate `playstore` folder.

---

## What you need
- A laptop with **Node.js 20 or newer** (https://nodejs.org)
- A free **Expo account** (https://expo.dev/signup) — Expo builds the Android file in the cloud, so you don't need Android Studio
- For the Play Store only: a **Google Play developer account** (one-time US$25)

## Step 1 — Install
Open a terminal in this folder and run:
```
npm install
npm install -g eas-cli
eas login
```

## Step 2 — Choose your app ID (once)
Open `app.json` and change `"package": "com.globepay.app"` to something unique to your team, for example `com.yourteamname.globepay`. Google Play rejects IDs that are already taken, and it can never be changed after you publish.

## Step 3 — Free test build (APK, install on any Android phone)
```
npm run build:apk
```
When asked, let EAS create a new Android keystore (it stores it safely for you). When the build finishes (about 10–20 minutes), you get a link. Open it on an Android phone, download the APK and install it (allow "install unknown apps" if asked). Share the same link with your team.

## Step 4 — Play Store build (AAB)
```
npm run build:playstore
```
This makes the `.aab` file Google Play needs. Download it from the link at the end.

## Step 5 — Publish on Google Play
1. Go to https://play.google.com/console → **Create app**. Name: *GlobePay: Global Payments Demo*, type *App*, *Free*.
2. **Store listing:** paste the text from `playstore/store-listing.md` and upload the icon, feature graphic and screenshots from the `playstore` folder.
3. **Privacy policy:** publish `playstore/privacy-policy.html` at a public web address (put your team email in it first) and paste the link.
4. **App content:** answer the questionnaires honestly:
   - Data safety: the app collects and shares **no data** (everything stays on the device).
   - Ads: **no ads**.
   - Financial features: explain it is a **concept demo with no real financial services**.
   - Target audience: 18+ is simplest.
5. **Testing → Closed testing:** create a track, upload the `.aab`, and add your testers' emails. New personal developer accounts must run a closed test with at least 12 testers for 14 days in a row before they can publish to everyone.
6. After the 14 days, apply for **Production** access, then send the release for review.

## Updating the app later
Change what you need, then increase `"versionCode"` in `app.json` (1 → 2 → 3…) and `"version"` (1.0.0 → 1.0.1), and run `npm run build:playstore` again.

To update the app's screens from a newer GlobePay web file, regenerate `src/site.js` from the new HTML (it's the whole page exported as one JavaScript string).

## Try it without building
`npx expo start` and scan the QR code with the **Expo Go** app on an Android phone.

## How it works
- `App.js` — a full-screen WebView that shows the bundled GlobePay app, handles the Android back button (steps back inside the app, exits from Overview) and opens outside links in the browser.
- `src/site.js` — the complete GlobePay app (HTML, CSS, JavaScript, fonts, Earth images, map data) in one file, with the marketing website parts switched off.
- `assets/` — app icon, Android adaptive-icon layers and splash screen, made from the GlobePay logo.
- Only the INTERNET permission is requested; camera, microphone, storage and other permissions are blocked.

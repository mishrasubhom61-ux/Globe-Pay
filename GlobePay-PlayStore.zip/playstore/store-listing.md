# GlobePay — Google Play store listing

Copy these into Play Console → Grow → Store presence → Main store listing.

## App name (30 characters max)
GlobePay: Global Payments Demo

## Short description (80 characters max)
Concept demo: send, spend and get paid worldwide. No real money moves.

## Full description (4,000 characters max)
GlobePay is a concept app that shows what borderless payments could feel like: one network for the whole planet, instant transfers and the real mid-market exchange rate, without the 3.5–4% "border tax" that banks and platforms charge.

IMPORTANT: GlobePay is a demonstration app made for a student marketing project. It does not move real money, connect to banks or cards, or provide any financial service. All balances, payments, cards and people in the app are sample data stored only on your phone.

WHAT YOU CAN TRY
• Overview: a multi-currency wallet with your total balance and how much you'd save versus bank fees
• Send money: pick a person or currency and watch a real 3D Earth turn to the destination as the route is drawn
• Pay abroad: scan-and-pay at stores around the world with zero foreign transaction fees
• Get paid: create a payment link and see a client in another country pay you
• Convert between currency wallets at the mid-market rate
• Virtual card: show details, freeze it, set a monthly limit and control online, abroad and contactless payments
• Activity and receipts: search every payment and see a full breakdown and timeline
• Business view: see tourist payments settle instantly in local currency
• Profile: add a photo, choose an avatar colour and edit your name, email, phone, date of birth and more
• Optional sign-in screens for Google or email (simulated)

BUILT FOR THREE KINDS OF PEOPLE
• Creators and freelancers who get paid by clients abroad
• Travellers who want to pay like a local anywhere
• Retailers who welcome international tourists

DESIGN
A cinematic Milky Way background, a realistic 3D Earth made from NASA Blue Marble imagery, and a glass interface that floats above the planet.

Exchange rates in the app are real mid-market rates captured on 23 Nov 2026 and do not update live.

## Category
Finance (or Education if you prefer to make the demo nature even clearer)

## Tags / contact
Contact email: add your team's email address (required).
Website: optional — you can use your GlobePay web link.

## Graphics in this folder
- App icon: app-icon-512.png (512 × 512)
- Feature graphic: feature-graphic-1024x500.png (1024 × 500)
- Phone screenshots: store-screenshot-1.png to store-screenshot-5.png (1080 × 1920)
